package com.example.obdmonitor

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Límites de temperatura (°C) — ajústalos si quieres
const val TEMP_NORMAL_MAX = 100
const val TEMP_DANGER = 105

class MainActivity : ComponentActivity() {
    private val obd = ObdManager()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) // pantalla siempre encendida
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF101418)) {
                    ObdApp(obd)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        obd.disconnect()
    }
}

@SuppressLint("MissingPermission")
@Composable
fun ObdApp(obd: ObdManager) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val adapter = remember { context.getSystemService(BluetoothManager::class.java)?.adapter }

    // Permiso de Bluetooth (Android 12 en adelante)
    val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
        Manifest.permission.BLUETOOTH_CONNECT else null
    var hasPermission by remember {
        mutableStateOf(
            permission == null ||
                ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { hasPermission = it }

    var status by remember { mutableStateOf("Desconectado") }
    var connected by remember { mutableStateOf(false) }
    var connecting by remember { mutableStateOf(false) }
    var data by remember { mutableStateOf(ObdData()) }
    var refresh by remember { mutableStateOf(0) }

    val devices = remember(hasPermission, refresh) {
        if (hasPermission) adapter?.bondedDevices?.toList().orEmpty() else emptyList()
    }

    // Ciclo de lectura: cada segundo mientras esté conectado
    LaunchedEffect(connected) {
        if (!connected) return@LaunchedEffect
        val beeper = ToneGenerator(AudioManager.STREAM_ALARM, 100)
        try {
            while (connected) {
                try {
                    data = obd.readAll()
                    val t = data.coolant
                    if (t != null && t >= TEMP_DANGER) {
                        beeper.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500)
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    status = "Conexión perdida: ${e.message}"
                    obd.disconnect()
                    connected = false
                }
                delay(1000)
            }
        } finally {
            beeper.release()
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Monitor OBD2", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(status, color = Color.LightGray)
        Spacer(Modifier.height(16.dp))

        when {
            adapter == null -> Text("Este teléfono no tiene Bluetooth.")

            !hasPermission -> Button(onClick = { permission?.let { launcher.launch(it) } }) {
                Text("Dar permiso de Bluetooth")
            }

            connected -> {
                Dashboard(data)
                Spacer(Modifier.height(16.dp))
                OutlinedButton(
                    onClick = {
                        connected = false
                        obd.disconnect()
                        status = "Desconectado"
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Desconectar") }
            }

            connecting -> Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator()
                Spacer(Modifier.width(12.dp))
                Text("Conectando… (puede tardar unos segundos)")
            }

            else -> {
                Text("Elige tu ELM327 (debe estar vinculado en Ajustes > Bluetooth, PIN 1234 o 0000):")
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.weight(1f)) {
                    items(devices) { device ->
                        Card(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    scope.launch {
                                        connecting = true
                                        status = "Conectando a ${device.name}…"
                                        try {
                                            obd.connect(device)
                                            connected = true
                                            status = "Conectado a ${device.name}"
                                        } catch (e: Exception) {
                                            status = "Error: ${e.message}"
                                            obd.disconnect()
                                        } finally {
                                            connecting = false
                                        }
                                    }
                                }
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(device.name ?: "Sin nombre", fontWeight = FontWeight.Bold)
                                Text(device.address, color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                }
                Button(onClick = { refresh++ }, modifier = Modifier.fillMaxWidth()) {
                    Text("Actualizar lista")
                }
            }
        }
    }
}

@Composable
fun Dashboard(d: ObdData) {
    val t = d.coolant
    val (tempColor, tempLabel) = when {
        t == null -> Color.Gray to "Sin dato"
        t < 80 -> Color(0xFF42A5F5) to "Calentando"
        t <= TEMP_NORMAL_MAX -> Color(0xFF66BB6A) to "Normal"
        t < TEMP_DANGER -> Color(0xFFFFCA28) to "Atención"
        else -> Color(0xFFEF5350) to "¡PELIGRO! Detén el carro"
    }

    val v = d.battery
    val batteryColor = when {
        v == null -> Color.White
        v < 11.8 -> Color(0xFFEF5350)                 // batería baja
        (d.rpm ?: 0) > 0 && v < 13.2 -> Color(0xFFFFCA28) // motor encendido pero no carga bien
        else -> Color(0xFF66BB6A)
    }

    val fuelText = when {
        d.fuel != null -> "%.0f %%".format(d.fuel)
        d.fuelSupported == false -> "No disponible"
        else -> "--"
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = tempColor.copy(alpha = 0.18f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                Modifier.fillMaxWidth().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Temperatura del motor", fontSize = 16.sp)
                Text(
                    t?.let { "$it °C" } ?: "--",
                    fontSize = 64.sp, fontWeight = FontWeight.Bold, color = tempColor
                )
                Text(tempLabel, fontSize = 20.sp, color = tempColor)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard("Velocidad", d.speed?.let { "$it km/h" } ?: "--", Modifier.weight(1f))
            InfoCard("RPM", d.rpm?.toString() ?: "--", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoCard("Batería", v?.let { "%.1f V".format(it) } ?: "--", Modifier.weight(1f), batteryColor)
            InfoCard("Combustible", fuelText, Modifier.weight(1f))
        }
    }
}

@Composable
fun InfoCard(title: String, value: String, modifier: Modifier = Modifier, valueColor: Color = Color.White) {
    Card(modifier) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Color.LightGray, fontSize = 14.sp)
            Text(value, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = valueColor)
        }
    }
}
