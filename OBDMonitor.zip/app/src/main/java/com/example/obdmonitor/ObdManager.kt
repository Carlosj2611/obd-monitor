package com.example.obdmonitor

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/** Datos leídos del carro. null = no hay dato. */
data class ObdData(
    val coolant: Int? = null,        // °C
    val speed: Int? = null,          // km/h
    val rpm: Int? = null,
    val battery: Double? = null,     // voltios
    val fuel: Double? = null,        // %
    val fuelSupported: Boolean? = null,
)

class ObdManager {

    companion object {
        // UUID estándar del perfil serie Bluetooth (SPP) que usa el ELM327
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var fuelSupported: Boolean? = null

    /** Conecta con el ELM327 y lo deja listo para leer datos. */
    @SuppressLint("MissingPermission")
    suspend fun connect(device: BluetoothDevice) = withContext(Dispatchers.IO) {
        disconnect()
        val s = try {
            device.createRfcommSocketToServiceRecord(SPP_UUID).also { it.connect() }
        } catch (e: IOException) {
            // Algunos clones baratos solo aceptan conexión "insegura"
            device.createInsecureRfcommSocketToServiceRecord(SPP_UUID).also { it.connect() }
        }
        socket = s
        input = s.inputStream
        output = s.outputStream
        fuelSupported = null

        send("ATZ", 4000)                 // reiniciar el ELM
        listOf(
            "ATE0",                        // sin eco
            "ATL0",                        // sin saltos de línea extra
            "ATS0",                        // sin espacios
            "ATH0",                        // sin encabezados
            "ATSP0",                       // protocolo automático
        ).forEach { send(it) }

        // Primera consulta: obliga al ELM a encontrar el protocolo del carro
        val r = send("0100", 10000).replace(" ", "")
        if (!r.contains("4100")) {
            throw IOException("El carro no respondió. ¿La llave está en ON?")
        }
    }

    /** Lee todos los datos una vez. */
    suspend fun readAll(): ObdData = withContext(Dispatchers.IO) {
        // Temperatura refrigerante: PID 05 -> A - 40
        val coolant = readPid("05")?.firstOrNull()?.let { it - 40 }

        // Velocidad: PID 0D -> A
        val speed = readPid("0D")?.firstOrNull()

        // RPM: PID 0C -> (256*A + B) / 4
        val rpm = readPid("0C")?.takeIf { it.size >= 2 }?.let { (it[0] * 256 + it[1]) / 4 }

        // Batería: el propio ELM mide el voltaje (responde algo como "12.6V")
        val battery = Regex("""\d+(\.\d+)?""").find(send("ATRV"))?.value?.toDoubleOrNull()

        // Combustible: PID 2F -> A * 100 / 255 (muchos carros no lo envían)
        var fuel: Double? = null
        if (fuelSupported != false) {
            fuel = readPid("2F")?.firstOrNull()?.let { it * 100.0 / 255 }
            if (fuelSupported == null) fuelSupported = fuel != null
        }

        ObdData(coolant, speed, rpm, battery, fuel, fuelSupported)
    }

    fun disconnect() {
        try { socket?.close() } catch (e: IOException) { }
        socket = null
        input = null
        output = null
    }

    /** Pide un PID del modo 01 y devuelve sus bytes de datos, o null si no hay respuesta. */
    private fun readPid(pid: String): List<Int>? {
        val marker = "41$pid"
        val line = send("01$pid")
            .lines()
            .map { it.replace(" ", "").trim().uppercase() }
            .firstOrNull { it.startsWith(marker) }
            ?: return null
        return line.removePrefix(marker)
            .chunked(2)
            .filter { it.length == 2 }
            .mapNotNull { it.toIntOrNull(16) }
    }

    /** Envía un comando y espera la respuesta hasta el símbolo '>'. */
    @Synchronized
    private fun send(cmd: String, timeoutMs: Long = 2000): String {
        val out = output ?: throw IOException("No conectado")
        val inp = input ?: throw IOException("No conectado")

        while (inp.available() > 0) inp.read()   // limpiar restos anteriores

        out.write("$cmd\r".toByteArray())
        out.flush()

        val sb = StringBuilder()
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (inp.available() > 0) {
                val c = inp.read()
                if (c == -1 || c == '>'.code) break
                sb.append(c.toChar())
            } else {
                Thread.sleep(10)
            }
        }
        return sb.toString().trim()
    }
}
